CREATE DATABASE IF NOT EXISTS electronic_voting_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE electronic_voting_db;

CREATE TABLE IF NOT EXISTS users (
  user_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('voter','admin') NOT NULL DEFAULT 'voter',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  mfa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  mfa_secret VARCHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS elections (
  election_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  description VARCHAR(1000) NULL,
  status ENUM('draft','open','closed','published') NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS candidates (
  candidate_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  election_id BIGINT NOT NULL,
  candidate_name VARCHAR(200) NOT NULL,
  UNIQUE KEY uq_candidate_election_name (election_id, candidate_name),
  CONSTRAINT fk_candidates_election FOREIGN KEY (election_id) REFERENCES elections(election_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS voter_eligibility (
  user_id BIGINT NOT NULL,
  election_id BIGINT NOT NULL,
  eligible BOOLEAN NOT NULL DEFAULT TRUE,
  PRIMARY KEY (user_id, election_id),
  CONSTRAINT fk_eligibility_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  CONSTRAINT fk_eligibility_election FOREIGN KEY (election_id) REFERENCES elections(election_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS voting_tokens (
  token_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  election_id BIGINT NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE KEY uq_token_user_election (user_id, election_id),
  UNIQUE KEY uq_token_hash (token_hash),
  CONSTRAINT fk_token_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  CONSTRAINT fk_token_election FOREIGN KEY (election_id) REFERENCES elections(election_id)
) ENGINE=InnoDB;

-- Deliberately no user_id or token_id in this table to reduce direct identity-to-ballot linkage.
CREATE TABLE IF NOT EXISTS votes (
  vote_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  election_id BIGINT NOT NULL,
  candidate_id BIGINT NOT NULL,
  integrity_tag CHAR(64) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_votes_election (election_id),
  CONSTRAINT fk_votes_election FOREIGN KEY (election_id) REFERENCES elections(election_id),
  CONSTRAINT fk_votes_candidate FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  event_id BIGINT PRIMARY KEY AUTO_INCREMENT,
  actor_id BIGINT NULL,
  event_type VARCHAR(100) NOT NULL,
  details JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_created (created_at),
  CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS election_results (
  election_id BIGINT NOT NULL,
  candidate_id BIGINT NOT NULL,
  vote_count BIGINT NOT NULL DEFAULT 0,
  result_hash CHAR(64) NOT NULL,
  verified_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (election_id, candidate_id),
  CONSTRAINT fk_results_election FOREIGN KEY (election_id) REFERENCES elections(election_id),
  CONSTRAINT fk_results_candidate FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id)
) ENGINE=InnoDB;
