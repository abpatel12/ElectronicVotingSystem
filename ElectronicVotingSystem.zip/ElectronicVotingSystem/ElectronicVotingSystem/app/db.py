import mysql.connector
from mysql.connector import pooling
from flask import current_app

_pool = None

def get_pool():
    global _pool
    if _pool is None:
        _pool = pooling.MySQLConnectionPool(
            pool_name="evs_pool",
            pool_size=5,
            host=current_app.config["MYSQL_HOST"],
            port=current_app.config["MYSQL_PORT"],
            user=current_app.config["MYSQL_USER"],
            password=current_app.config["MYSQL_PASSWORD"],
            database=current_app.config["MYSQL_DATABASE"],
            autocommit=False,
        )
    return _pool

def get_connection():
    return get_pool().get_connection()

def reset_pool_for_tests():
    global _pool
    _pool = None
