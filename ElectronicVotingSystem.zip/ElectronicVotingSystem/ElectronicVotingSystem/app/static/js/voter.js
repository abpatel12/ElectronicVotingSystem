async function api(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
async function loadElections() {
  const holder = document.querySelector('#elections');
  try {
    const data = await api('/api/elections');
    holder.innerHTML = '';
    if (!data.elections.length) { holder.textContent = 'No open elections are available.'; return; }
    for (const election of data.elections) {
      const card = document.createElement('article'); card.className = 'election';
      const title = document.createElement('h3'); title.textContent = election.title;
      const desc = document.createElement('p'); desc.className = 'muted'; desc.textContent = election.description || '';
      const button = document.createElement('button'); button.className = 'button'; button.textContent = 'Open ballot';
      button.addEventListener('click', () => openBallot(election.election_id, election.title));
      card.append(title, desc, button); holder.append(card);
    }
  } catch (e) { holder.textContent = e.message; }
}
async function openBallot(electionId, title) {
  const holder = document.querySelector('#elections');
  const message = document.querySelector('#message');
  try {
    const tokenData = await api('/api/voting/token', {method:'POST', body:JSON.stringify({election_id:electionId})});
    const candidateData = await api(`/api/candidates/${electionId}`);
    if (!candidateData.candidates.length) throw new Error('No candidates are configured for this election.');
    holder.innerHTML = '';
    const heading = document.createElement('h2'); heading.textContent = title;
    holder.append(heading);
    const form = document.createElement('form'); form.className = 'stack';
    for (const candidate of candidateData.candidates) {
      const card = document.createElement('div'); card.className = 'candidate';
      const label = document.createElement('label');
      const radio = document.createElement('input'); radio.type = 'radio'; radio.name = 'candidate'; radio.value = candidate.candidate_id; radio.required = true;
      const span = document.createElement('span'); span.textContent = candidate.candidate_name;
      label.append(radio, span); card.append(label); form.append(card);
    }
    const submit = document.createElement('button'); submit.className = 'button'; submit.textContent = 'Submit vote'; form.append(submit);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const chosen = form.querySelector('input[name=candidate]:checked');
      if (!chosen) return;
      submit.disabled = true;
      try {
        await api('/api/votes', {method:'POST',body:JSON.stringify({election_id:electionId,candidate_id:Number(chosen.value),token:tokenData.token})});
        message.textContent = 'Your vote was recorded. The system does not display your selected candidate in the confirmation.';
        message.className = 'message success';
        holder.innerHTML = '';
      } catch (e) { message.textContent = e.message; message.className = 'message error'; submit.disabled = false; }
    });
    holder.append(form);
    message.textContent = `Token expires at ${tokenData.expires_at}. Keep it private.`;
    message.className = 'message';
  } catch (e) { message.textContent = e.message; message.className = 'message error'; }
}
async function logout() { await fetch('/api/logout',{method:'POST'}); window.location.href='/login'; }
loadElections();
