async function api(url, options={}) {
  const response = await fetch(url, {headers:{'Content-Type':'application/json'}, ...options});
  const data = await response.json().catch(()=>({error:'Unexpected response'}));
  if (!response.ok) throw new Error(JSON.stringify(data, null, 2));
  return data;
}
function electionId() { return Number(document.querySelector('#election-id').value); }
async function runAction(path, body={}) {
  const output = document.querySelector('#output'); output.textContent = 'Working…';
  try { output.textContent = JSON.stringify(await api(path,{method:'POST',body:JSON.stringify(body)}),null,2); }
  catch (e) { output.textContent = e.message; }
}
function countVotes() { return runAction('/api/admin/count',{election_id:electionId()}); }
function verifyResults() { return runAction('/api/admin/verify-results',{election_id:electionId()}); }
function createBackup() { return runAction('/api/admin/backup',{}); }
async function loadLogs() {
  const output = document.querySelector('#output'); output.textContent = 'Loading…';
  try { output.textContent = JSON.stringify(await api('/api/admin/audit-logs'),null,2); }
  catch (e) { output.textContent = e.message; }
}
async function logout() { await fetch('/api/logout',{method:'POST'}); window.location.href='/login'; }
