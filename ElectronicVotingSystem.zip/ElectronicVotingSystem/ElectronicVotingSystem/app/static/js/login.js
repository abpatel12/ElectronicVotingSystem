const form = document.querySelector('#login-form');
const message = document.querySelector('#message');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.textContent = 'Checking credentials…';
  message.className = 'message';
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch('/api/login', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data = await response.json();
    if (data.mfa_required) {
      message.textContent = 'MFA is enabled for this account. Enter the current authenticator code and submit again.';
      message.className = 'message';
      return;
    }
    if (!response.ok) throw new Error(data.error || 'Login failed');
    message.textContent = 'Login successful. Redirecting…';
    message.className = 'message success';
    window.location.href = data.redirect;
  } catch (error) {
    message.textContent = error.message;
    message.className = 'message error';
  }
});
