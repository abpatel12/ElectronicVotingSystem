from flask import Flask, jsonify, render_template
from config import Config
from .routes import register_routes

def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/health")
    def health():
        # Do not expose environment variables or database credentials here.
        return jsonify({"status": "ok", "service": "electronic-voting-prototype"}), 200

    register_routes(app)
    return app
