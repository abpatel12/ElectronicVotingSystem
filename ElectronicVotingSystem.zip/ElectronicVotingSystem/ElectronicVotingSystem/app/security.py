import hashlib
import hmac
import secrets
import time
from functools import wraps
from flask import session, jsonify, current_app, request

# Demonstration-only in-process throttling. Use Redis or another shared store in a real deployment.
_login_attempts = {}

def hash_token(raw_token: str) -> str:
    return hashlib.sha256(raw_token.encode("utf-8")).hexdigest()

def generate_token() -> str:
    return secrets.token_urlsafe(32)

def ballot_payload(election_id: int, candidate_id: int, ballot_id: int) -> bytes:
    return f"{ballot_id}:{election_id}:{candidate_id}".encode("utf-8")

def make_ballot_hmac(election_id: int, candidate_id: int, ballot_id: int, key: str) -> str:
    if not key:
        raise RuntimeError("VOTE_HMAC_KEY is not configured. Set it in .env.")
    return hmac.new(key.encode("utf-8"), ballot_payload(election_id, candidate_id, ballot_id), hashlib.sha256).hexdigest()

def verify_ballot_hmac(election_id: int, candidate_id: int, ballot_id: int, tag: str, key: str) -> bool:
    try:
        expected = make_ballot_hmac(election_id, candidate_id, ballot_id, key)
    except RuntimeError:
        return False
    return hmac.compare_digest(expected, tag or "")

def make_result_hash(election_id: int, counts: dict, key: str) -> str:
    if not key:
        raise RuntimeError("VOTE_HMAC_KEY is not configured. Set it in .env.")
    canonical = "|".join(f"{cid}:{counts[cid]}" for cid in sorted(counts))
    payload = f"{election_id}|{canonical}".encode("utf-8")
    return hmac.new(key.encode("utf-8"), payload, hashlib.sha256).hexdigest()

def verify_result_hash(election_id: int, counts: dict, tag: str, key: str) -> bool:
    try:
        return hmac.compare_digest(make_result_hash(election_id, counts, key), tag or "")
    except RuntimeError:
        return False

def login_rate_limited(identity: str, now=None, max_attempts=5, window_seconds=300):
    now = now or time.time()
    entries = [t for t in _login_attempts.get(identity, []) if now - t < window_seconds]
    _login_attempts[identity] = entries
    return len(entries) >= max_attempts

def record_failed_login(identity: str, now=None):
    _login_attempts.setdefault(identity, []).append(now or time.time())

def clear_failed_logins(identity: str):
    _login_attempts.pop(identity, None)

def require_login(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return jsonify({"error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapper

def require_role(*roles):
    def decorator(fn):
        @wraps(fn)
        @require_login
        def wrapper(*args, **kwargs):
            if session.get("role") not in roles:
                return jsonify({"error": "Forbidden"}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator
