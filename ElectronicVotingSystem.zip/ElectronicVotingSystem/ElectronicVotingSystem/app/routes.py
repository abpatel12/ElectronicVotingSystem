from datetime import datetime, timedelta, timezone
import json
import os
import shutil
from flask import jsonify, request, session, redirect, url_for, render_template, current_app
from werkzeug.security import check_password_hash
from .db import get_connection
from .security import (
    hash_token, generate_token, make_ballot_hmac, verify_ballot_hmac,
    make_result_hash, verify_result_hash, login_rate_limited,
    record_failed_login, clear_failed_logins, require_login, require_role
)

def _audit(conn, event_type, actor_id=None, details=None):
    # Never include a selected candidate or raw voting token in audit details.
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO audit_logs (actor_id, event_type, details) VALUES (%s, %s, %s)",
        (actor_id, event_type, json.dumps(details or {}))
    )
    cur.close()

def register_routes(app):
    @app.get("/login")
    def login_page():
        return render_template("login.html")

    @app.post("/api/login")
    def login():
        data = request.get_json(silent=True) or request.form
        username = (data.get("username") or "").strip()[:100]
        password = data.get("password") or ""
        identity = username.lower()
        if not username or not password:
            return jsonify({"error": "Username and password are required"}), 400
        if login_rate_limited(identity):
            return jsonify({"error": "Too many failed attempts; try again later"}), 429

        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT user_id, username, password_hash, role, mfa_enabled, mfa_secret, is_active FROM users WHERE username=%s", (username,))
            user = cur.fetchone()
            cur.close()
            if not user or not user["is_active"] or not check_password_hash(user["password_hash"], password):
                record_failed_login(identity)
                _audit(conn, "login_failed", None, {"username": username})
                conn.commit()
                return jsonify({"error": "Invalid credentials"}), 401

            if user["mfa_enabled"]:
                code = data.get("totp_code") or ""
                if not code:
                    return jsonify({"mfa_required": True}), 200
                try:
                    import pyotp
                    valid = pyotp.TOTP(user["mfa_secret"]).verify(code, valid_window=1)
                except Exception:
                    valid = False
                if not valid:
                    record_failed_login(identity)
                    _audit(conn, "mfa_failed", user["user_id"])
                    conn.commit()
                    return jsonify({"error": "Invalid MFA code"}), 401

            clear_failed_logins(identity)
            session.clear()
            session["user_id"] = user["user_id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            _audit(conn, "login_success", user["user_id"])
            conn.commit()
            return jsonify({"message": "Login successful", "role": user["role"], "redirect": "/admin" if user["role"] == "admin" else "/voter"}), 200
        finally:
            conn.close()

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify({"message": "Logged out"}), 200

    @app.get("/voter")
    def voter_page():
        if not session.get("user_id"):
            return redirect(url_for("login_page"))
        if session.get("role") != "voter":
            return "Forbidden", 403
        return render_template("voter.html")

    @app.get("/admin")
    def admin_page():
        if not session.get("user_id"):
            return redirect(url_for("login_page"))
        if session.get("role") != "admin":
            return "Forbidden", 403
        return render_template("admin.html")

    @app.get("/api/elections")
    @require_login
    def elections():
        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT election_id, title, description, status FROM elections WHERE status='open' ORDER BY election_id")
            rows = cur.fetchall()
            cur.close()
            return jsonify({"elections": rows})
        finally:
            conn.close()

    @app.post("/api/voting/token")
    @require_role("voter")
    def issue_token():
        data = request.get_json(silent=True) or {}
        try:
            election_id = int(data.get("election_id"))
        except (TypeError, ValueError):
            return jsonify({"error": "Valid election_id is required"}), 400

        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT status FROM elections WHERE election_id=%s", (election_id,))
            election = cur.fetchone()
            if not election or election["status"] != "open":
                return jsonify({"error": "Election is not open"}), 400
            cur.execute("SELECT eligible FROM voter_eligibility WHERE user_id=%s AND election_id=%s", (session["user_id"], election_id))
            eligibility = cur.fetchone()
            if not eligibility or not eligibility["eligible"]:
                _audit(conn, "eligibility_denied", session["user_id"], {"election_id": election_id})
                conn.commit()
                return jsonify({"error": "Voter is not eligible"}), 403
            cur.execute("SELECT 1 FROM voting_tokens WHERE user_id=%s AND election_id=%s AND used=1 LIMIT 1", (session["user_id"], election_id))
            if cur.fetchone():
                return jsonify({"error": "A vote has already been recorded for this election"}), 409
            raw = generate_token()
            digest = hash_token(raw)
            expires = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(minutes=current_app.config["TOKEN_TTL_MINUTES"])
            cur.execute("INSERT INTO voting_tokens (user_id, election_id, token_hash, expires_at, used) VALUES (%s,%s,%s,%s,0) ON DUPLICATE KEY UPDATE token_hash=VALUES(token_hash), expires_at=VALUES(expires_at), used=0", (session["user_id"], election_id, digest, expires))
            _audit(conn, "token_issued", session["user_id"], {"election_id": election_id})
            conn.commit()
            return jsonify({"token": raw, "expires_at": expires.isoformat() + "Z"}), 200
        finally:
            conn.close()

    @app.get("/api/candidates/<int:election_id>")
    @require_login
    def candidates(election_id):
        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT candidate_id, candidate_name FROM candidates WHERE election_id=%s ORDER BY candidate_id", (election_id,))
            rows = cur.fetchall()
            cur.close()
            return jsonify({"candidates": rows})
        finally:
            conn.close()

    @app.post("/api/votes")
    @require_role("voter")
    def submit_vote():
        data = request.get_json(silent=True) or {}
        raw = data.get("token") or ""
        try:
            election_id, candidate_id = int(data.get("election_id")), int(data.get("candidate_id"))
        except (TypeError, ValueError):
            return jsonify({"error": "Valid election_id and candidate_id are required"}), 400
        if not raw or len(raw) > 200:
            return jsonify({"error": "Valid voting token is required"}), 400
        if not current_app.config["VOTE_HMAC_KEY"]:
            return jsonify({"error": "VOTE_HMAC_KEY is not configured"}), 500

        conn = get_connection()
        try:
            conn.start_transaction()
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT status FROM elections WHERE election_id=%s FOR UPDATE", (election_id,))
            election = cur.fetchone()
            if not election or election["status"] != "open":
                conn.rollback()
                return jsonify({"error": "Election is not open"}), 400
            cur.execute("SELECT candidate_id FROM candidates WHERE candidate_id=%s AND election_id=%s", (candidate_id, election_id))
            if not cur.fetchone():
                conn.rollback()
                return jsonify({"error": "Candidate does not belong to this election"}), 400
            cur.execute("SELECT token_id, expires_at, used FROM voting_tokens WHERE user_id=%s AND election_id=%s AND token_hash=%s FOR UPDATE", (session["user_id"], election_id, hash_token(raw)))
            token = cur.fetchone()
            if not token or token["used"] or token["expires_at"] <= datetime.utcnow():
                conn.rollback()
                return jsonify({"error": "Invalid, expired or already-used token"}), 409
            cur.execute("UPDATE voting_tokens SET used=1 WHERE token_id=%s AND used=0", (token["token_id"],))
            if cur.rowcount != 1:
                conn.rollback()
                return jsonify({"error": "Token has already been used"}), 409
            cur.execute("INSERT INTO votes (election_id, candidate_id, integrity_tag) VALUES (%s,%s,'PENDING')", (election_id, candidate_id))
            ballot_id = cur.lastrowid
            tag = make_ballot_hmac(election_id, candidate_id, ballot_id, current_app.config["VOTE_HMAC_KEY"])
            cur.execute("UPDATE votes SET integrity_tag=%s WHERE vote_id=%s", (tag, ballot_id))
            _audit(conn, "vote_submitted", session["user_id"], {"election_id": election_id})
            conn.commit()
            return jsonify({"message": "Vote submitted successfully"}), 201
        except Exception:
            conn.rollback()
            app.logger.exception("Vote submission failed")
            return jsonify({"error": "Vote submission failed"}), 500
        finally:
            conn.close()

    @app.post("/api/admin/count")
    @require_role("admin")
    def count_votes():
        data = request.get_json(silent=True) or {}
        try:
            election_id = int(data.get("election_id"))
        except (TypeError, ValueError):
            return jsonify({"error": "Valid election_id is required"}), 400
        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT vote_id, election_id, candidate_id, integrity_tag FROM votes WHERE election_id=%s ORDER BY vote_id", (election_id,))
            ballots = cur.fetchall()
            for ballot in ballots:
                if not verify_ballot_hmac(ballot["election_id"], ballot["candidate_id"], ballot["vote_id"], ballot["integrity_tag"], current_app.config["VOTE_HMAC_KEY"]):
                    _audit(conn, "vote_integrity_failed", session["user_id"], {"election_id": election_id, "vote_id": ballot["vote_id"]})
                    conn.commit()
                    return jsonify({"error": "Vote integrity verification failed", "vote_id": ballot["vote_id"]}), 409
            counts = _count_primary(ballots)
            independent = _count_independent(ballots)
            if counts != independent:
                _audit(conn, "recount_mismatch", session["user_id"], {"election_id": election_id})
                conn.commit()
                return jsonify({"error": "Independent recount mismatch; publication blocked"}), 409
            result_hash = make_result_hash(election_id, counts, current_app.config["VOTE_HMAC_KEY"])
            cur2 = conn.cursor()
            for candidate_id, vote_count in counts.items():
                cur2.execute("INSERT INTO election_results (election_id, candidate_id, vote_count, result_hash) VALUES (%s,%s,%s,%s) ON DUPLICATE KEY UPDATE vote_count=VALUES(vote_count), result_hash=VALUES(result_hash)", (election_id, candidate_id, vote_count, result_hash))
            _audit(conn, "count_verified", session["user_id"], {"election_id": election_id, "ballots": len(ballots)})
            conn.commit()
            return jsonify({"election_id": election_id, "counts": counts, "independent_recount": independent, "verified": True, "result_hash": result_hash}), 200
        finally:
            conn.close()

    @app.post("/api/admin/verify-results")
    @require_role("admin")
    def verify_results():
        data = request.get_json(silent=True) or {}
        try:
            election_id = int(data.get("election_id"))
        except (TypeError, ValueError):
            return jsonify({"error": "Valid election_id is required"}), 400
        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT candidate_id, vote_count, result_hash FROM election_results WHERE election_id=%s ORDER BY candidate_id", (election_id,))
            rows = cur.fetchall()
            if not rows:
                return jsonify({"error": "No stored results found"}), 404
            counts = {r["candidate_id"]: r["vote_count"] for r in rows}
            tags = {r["result_hash"] for r in rows}
            valid = len(tags) == 1 and verify_result_hash(election_id, counts, next(iter(tags)), current_app.config["VOTE_HMAC_KEY"])
            return jsonify({"election_id": election_id, "verified": valid}), 200 if valid else 409
        finally:
            conn.close()

    @app.get("/api/admin/audit-logs")
    @require_role("admin")
    def audit_logs():
        conn = get_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT event_id, actor_id, event_type, details, created_at FROM audit_logs ORDER BY event_id DESC LIMIT 200")
            rows = cur.fetchall()
            cur.close()
            for row in rows:
                if isinstance(row.get("details"), str):
                    try: row["details"] = json.loads(row["details"])
                    except ValueError: pass
            return jsonify({"events": rows})
        finally:
            conn.close()

    @app.post("/api/admin/backup")
    @require_role("admin")
    def backup():
        # Logical backup using Python connector. For coursework demonstration only.
        import csv
        from pathlib import Path
        target_dir = Path("backups")
        target_dir.mkdir(exist_ok=True)
        filename = target_dir / f"votes-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}.csv"
        conn = get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT vote_id, election_id, candidate_id, integrity_tag FROM votes ORDER BY vote_id")
            rows = cur.fetchall()
            with filename.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.writer(handle)
                writer.writerow(["vote_id", "election_id", "candidate_id", "integrity_tag"])
                writer.writerows(rows)
            _audit(conn, "vote_backup_created", session["user_id"], {"records": len(rows)})
            conn.commit()
            return jsonify({"message": "Backup created", "records": len(rows), "file": str(filename)}), 200
        finally:
            conn.close()

def _count_primary(ballots):
    counts = {}
    for ballot in ballots:
        cid = ballot["candidate_id"]
        counts[cid] = counts.get(cid, 0) + 1
    return counts

def _count_independent(ballots):
    # Separate implementation, intentionally does not call _count_primary.
    candidate_ids = {ballot["candidate_id"] for ballot in ballots}
    return {cid: sum(1 for ballot in ballots if ballot["candidate_id"] == cid) for cid in candidate_ids}
