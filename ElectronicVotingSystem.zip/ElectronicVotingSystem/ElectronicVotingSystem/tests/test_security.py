import unittest
from app.security import (
    hash_token, generate_token, make_ballot_hmac, verify_ballot_hmac,
    make_result_hash, verify_result_hash, login_rate_limited,
    record_failed_login, clear_failed_logins
)

class SecurityTests(unittest.TestCase):
    def setUp(self):
        clear_failed_logins("unit-test-user")

    def test_token_hash_is_deterministic(self):
        self.assertEqual(hash_token("example"), hash_token("example"))

    def test_generated_tokens_differ(self):
        self.assertNotEqual(generate_token(), generate_token())

    def test_hmac_verifies_original_ballot(self):
        key = "test-only-secret-key"
        tag = make_ballot_hmac(1, 2, 3, key)
        self.assertTrue(verify_ballot_hmac(1, 2, 3, tag, key))

    def test_hmac_rejects_modified_ballot(self):
        key = "test-only-secret-key"
        tag = make_ballot_hmac(1, 2, 3, key)
        self.assertFalse(verify_ballot_hmac(1, 9, 3, tag, key))

    def test_result_hash_detects_change(self):
        key = "test-only-secret-key"
        counts = {1: 3, 2: 4}
        tag = make_result_hash(7, counts, key)
        self.assertTrue(verify_result_hash(7, counts, tag, key))
        self.assertFalse(verify_result_hash(7, {1: 3, 2: 5}, tag, key))

    def test_login_throttle_threshold(self):
        for _ in range(5):
            record_failed_login("unit-test-user", now=1000)
        self.assertTrue(login_rate_limited("unit-test-user", now=1001))
        clear_failed_logins("unit-test-user")
        self.assertFalse(login_rate_limited("unit-test-user", now=1001))

if __name__ == "__main__":
    unittest.main()
